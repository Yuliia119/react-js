import reactLogo from '../../assets/react.svg'
import './lesson01.css'

function Lesson01() {

    return (
      <div className='react-container'>
      <img src="/vite.svg" alt="" />
      <img src={reactLogo} alt="" />
      <h1>Hello, Reakt!</h1>
      </div>
    )
  }

  export default Lesson01