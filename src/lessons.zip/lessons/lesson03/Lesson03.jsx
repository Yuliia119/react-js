import UserCard from '../../components/userCard/UserCard'

function Lesson03 () {
    const friends = [
        {name: 'Peter', age: 40, hobby: 'coding'},
        {name: 'Rosa', age: 35, hobby: 'hiking'},
        {name:"Anton", age:"20", hobby:"painting"}
      ]
    return (
        <div>
 <h1>Lesson 3: react props 👨‍👩‍👧‍👦</h1>
      <UserCard name={friends[0].name} age={friends[0].age} hobby={friends[0].hobby}/>
      <UserCard name="Rosa" age={35}/>
      <UserCard name="Anton" age={20} hobby="painting"/>
        </div>
    )
}
export default Lesson03